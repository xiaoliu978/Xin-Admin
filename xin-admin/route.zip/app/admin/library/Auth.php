<?php

class Auth extends Collator 
{

    public function login()
    {
        
    }


}