<?php

namespace app\admin\model\system;

use app\common\model\BaseModel;

class DictItem extends BaseModel
{

}