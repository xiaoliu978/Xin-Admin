<?php

namespace app\admin\model;

use think\Model;

class AdminRule extends Model
{

}