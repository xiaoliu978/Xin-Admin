<?php
namespace app\common\lib;


class Auth
{


    public function __construct()
    {

    }

    public static function getToken($data) 
    {
       
    }

    public static function verifyToken($token) 
    {
        
    }
}